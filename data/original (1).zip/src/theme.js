export const THEME = {
  MAIN_COLOR: '#303f9f',
  DANGER_COLOR: '#d81b60'
}
